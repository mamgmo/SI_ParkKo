var myApp = angular.module('ParkKoApp', []);

myApp.controller('ConfigurationController', ['$scope', function($scope) {
    $scope.Rule1 = true;
    $scope.Rule2 = true;
    $scope.Rule3 = true;
    $scope.Rule4 = true;
    $scope.Rule5 = true;
    $scope.Rule6 = true;                

    $scope.Key1 = "";  
    $scope.Key2 = "";          
    $scope.Key3 = "";    
	$scope.Key4 = "";    
	$scope.Key5 = "";    
	$scope.Key6 = "";    
	$scope.Key7 = "";    
	$scope.Key8 = "";    
	$scope.Key9 = "";    
	$scope.Key10 = "";    
	$scope.Key11 = "";    
	$scope.Key12 = "";    
	
    $scope.IsSave = false;


    // $scope.chiliSpicy = function() {
    //     $scope.spice = 'chili';
    // };

    // $scope.jalapenoSpicy = function() {
    //     $scope.spice = 'jalapeño';
    // };
}]);